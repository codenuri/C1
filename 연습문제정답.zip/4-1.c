#include <stdio.h>

int main(void)
{
	int x[10] = {0};

	for ( int i = 0; i < 10; i++)
	{
		x[i] = i+1;
	}

	int j = 0;
	int sum = 0;
	while( j < 10)
	{
		sum += x[j];
		++j;
	}
	printf("%d\n", sum);
}
#include <stdio.h>

int main(void)
{
	int x[5] = {1,2,3,4,5};

	int *p = &x[0];

	for ( int i = 0; i < 5; i++)
	{
		printf("%d, ", *(p+i));
	}
}
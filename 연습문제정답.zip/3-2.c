#include <stdio.h>

int main()
{
	int n = 0;

	scanf_s("%d", &n);

	if ( n % 3 == 0 || n % 5 == 0 )
		printf("3 또는 5의 배수 입니다.\n");

	if ( n & 1 )
		printf("홀수 입니다.\n");
	else 
		printf("짝수 입니다.\n");
}
#include <stdio.h>

int factorial(int n)
{
	int s = 1;
	
	for( int i = 1; i <= n; i++)
		s *= i;

	return s;
}
int main(void)
{
	int n = 0;
	scanf_s("%d", &n);

	printf("%d\n", factorial(n));
}
#include <stdio.h>

int main(void)
{
	puts("[ 메뉴를 선택하세요 ]");
	puts("1. 김밥");
	puts("2. 갈비탕");
	puts("3. 칼국수");
}
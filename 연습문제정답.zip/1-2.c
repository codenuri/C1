#include <stdio.h>

int main(void)
{
	printf("[ 메뉴를 선택하세요 ]\n");
	printf("1. 김밥\n");
	printf("2. 갈비탕\n");
	printf("3. 칼국수\n");
}
#include <stdio.h>

int main(void)
{
	double d = 3.4;
	double *p = &d;

	*p = 1.1;

	printf("%lf, %p\n", d, &d);
	printf("%p, %p, %lf\n", p, &p, *p);
}
#include <stdio.h>

int main(void)
{
	int i = 0, j = 0, k = 0;

	// 실제 입력 받으려면 아래 한줄을 주석으로 막고, 
	int score[2][3][2] = { 10,20,30,40,50,60,70,80,90,10,20,30 };

	// 아래 코드의 주석을 풀고 실행하면 됩니다.
	/*
	// 점수 입력 받기
	// 2개 학급, 학급당 3명,  과목 2개
	int score[2][3][2] = { 0 };

	for (i = 0; i < 2; i++)
	{
		for (j = 0; j < 3; j++)
		{
			for (k = 0; k < 2; k++)
			{
				printf("%d 반, %d 번째 학생의 %d번째 과목점수를 입력해 주세요 > ", i + 1, j + 1, k + 1);
				scanf_s("%d", &score[i][j][k]);
			}
		}
	}
	*/



	// 과목별 총점과 평균
	int total1 = 0, total2 = 0;	// 배열로 해도 됩니다.

	for (i = 0; i < 2; i++)
	{
		for (j = 0; j < 3; j++)
		{
			total1 += score[i][j][0];
			total2 += score[i][j][1];
		}
	}

	printf("과목 1 : 총점 %d, 평균 : %lf\n", total1, (double)total1 / 6);
	printf("과목 2 : 총점 %d, 평균 : %lf\n", total2, (double)total2 / 6);

	// 학급별 총점, 평균
	int total3 = 0, total4 = 0;	// 배열로 해도 됩니다.

	for (j = 0; j < 3; j++)
	{
		for (k = 0; k < 2; k++)
		{
			total3 += score[0][j][k];
			total4 += score[1][j][k];
		}
	}

	printf("1반 : 총점 %d, 평균 : %lf\n", total3, (double)total3 / 6);
	printf("2반 : 총점 %d, 평균 : %lf\n", total4, (double)total4 / 6);
}
#include <stdio.h>

int main(void)
{
	int i = 1;
	
	while( i <= 9)
	{
		printf("5 * %d = %2d\n", i, 5 * i);
		++i;
	}

}
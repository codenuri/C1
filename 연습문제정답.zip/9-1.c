struct _complex {
	double real;
	double image;
};

typedef struct _complex complex;

int main(void)
{
	complex c1 = {1, 2};
}
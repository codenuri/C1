#include <stdio.h>

int main(void)
{
	int age = 0;

	do 
	{
		scanf_s("%d", &age);
	}
	while(age < 1 || age > 120);

	printf("age is %d\n", age);
}
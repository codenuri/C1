#include <stdio.h>

int arithmetic(int a, int b, int *sub, int *mul, int *div)
{
	*sub = a - b;
	*mul = a * b;

	if ( b != 0)
		*div = a / b;
	else 
		*div = 0;

	return a + b;
}

int main(void)
{
	int sub = 0, mul = 0, div = 0;
	int add = arithmetic(8, 4, &sub, &mul, &div);

	printf("%d, %d, %d, %d\n", add, sub, mul, div);
}
#include <stdio.h>

void draw1()
{

}
void draw2()
{
	// 3-7.c 소스
}

int main(void)
{
	int n = 0;

	while( 1 )
	{
		scanf_s("%d", &n);
		if ( n == 1 )
			draw1();
		else if( n == 2)
			draw2();
	}
}
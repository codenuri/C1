#include <stdio.h>

int main(void)
{
	char   c = 1;
	short  s = 2;
	int    n = 3;
	float  f = 1.1;
	double d = 2.2;

	printf("%d, %p, %zd\n", c, &c, sizeof(c));
	printf("%d, %p, %zd\n", s, &s, sizeof(s));
	printf("%d, %p, %zd\n", n, &n, sizeof(n));
	printf("%f, %p, %zd\n", f, &f, sizeof(f));
	printf("%lf, %p, %zd\n", d, &d, sizeof(d));
}
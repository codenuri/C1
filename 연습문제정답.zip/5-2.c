#include <stdio.h>

int calc(int cmd, int a, int b)
{
	switch(cmd)
	{
		case 1: return a + b;
		case 2: return a - b;
		case 3: return a * b;
		case 4: if ( b != 0) return a / b;
	}
	return -99; // fail!!
}

int main(void)
{
	int cmd = 0, a = 0, b = 0;

	scanf_s("%d", &cmd);
	scanf_s("%d", &a);
	scanf_s("%d", &b);

	printf("%d\n", calc(cmd, a, b));
}

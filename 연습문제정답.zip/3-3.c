#include <stdio.h>

int main(void)
{
	int n = 0;

	scanf_s("%d", &n);

	if ( n % 400 == 0 || ( ( n % 4 == 0) && (n % 100 != 0) ))
		printf("윤년입니다\n");
	else 
		printf("윤년이 아닙니다.\n");
}
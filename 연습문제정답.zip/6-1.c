#include <stdio.h>

int main(void)
{
    int num1 = 10;
    int num2 = 20;

	int *pnum = &num1;
	*pnum = 20;
	pnum = &num2;
	*pnum = 30;
 
    printf("%d\n", num1); // 20 이 나와야 합니다.
    printf("%d\n", num2); // 30 이 나와야 합니다.
}

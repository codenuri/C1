#include <stdio.h>

int main(void)
{
	int n1 = 20;
	int n2 = 10;

	printf("%2d + %2d = %3d\n", n1, n2, n1 + n2);
	printf("%2d - %2d = %3d\n", n1, n2, n1 - n2);
	printf("%2d * %2d = %3d\n", n1, n2, n1 * n2);
	printf("%2d / %2d = %3d\n", n1, n2, n1 / n2);
}
#include <stdio.h>

int main(void)
{
	int age = 0;

	printf("input age > ");
	scanf_s("%d", &age);

	if ( age <= 0)
		printf("잘못 입력 하셨습니다\n");

	else if ( age >= 1 && age <= 9 )
		printf("아동입니다.\n");

	else if ( age >= 10 && age <= 19 )
		printf("10대 입니다\n열심히 공부하세요.\n");

	else if ( age >= 20 && age <= 29 )
		printf("20대 입니다\n");

	else if ( age >= 30 )
		printf("30대 입니다\n");
}
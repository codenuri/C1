#include <stdio.h>

int main(void)
{
	int n = 0;
	int odd_sum = 0;
	int even_sum = 0;
	int i = 0;
	
	scanf_s("%d", &n);

	while( i <= n )
	{
		if ( i % 2 == 0)
			even_sum += i;
		else 
			odd_sum += i;
		++i;
	}
	printf("odd  sum : %d\n", odd_sum);
	printf("even sum : %d\n", even_sum);
}
	